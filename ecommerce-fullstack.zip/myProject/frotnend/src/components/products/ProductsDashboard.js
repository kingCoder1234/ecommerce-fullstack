import React from "react";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";

const ProductsDashboard = ({
  products,
  Loggedinuser,
  handleAddToCart,
  handleRemoveProduct,
  // handleEditProduct,
}) => {
  const handleEditProduct=()=>{
    alert("Work in progress!")
  }
  let count = 0;
  const dispatch = useDispatch();

  const renderList = products.map((product) => {
    const { _id, title, image, price, category, description, rating } = product;
    {
      count++;
    }
    return (
      <div
        className="col-lg-4 col-md-4 col-sm-6 mb-4 px-4 border border-red"
        key={_id}
      >
        <div className="card h-100">
          <Link to={`/products/${_id}`} className="text-decoration-none">
            <img src={image} className="card-img-top" alt={title} />
            <div className="card-body">
              <h4 className="card-title">{title}</h4>
              <h5 className="card-text">${price}</h5>
              <h5 className="card-text">{category}</h5>
              <h6 className="card-text">rating : {rating.rate}/{rating.count}</h6>
              <p className="card-text">{description.slice(0, 60) + "..."}</p>
            </div>
          </Link>
          <div className="d-flex justify-content-between">
            {Loggedinuser && Loggedinuser.isAdmin ? (
              <>
                <button
                  className="btn btn-primary"
                  onClick={() => handleRemoveProduct(_id)}
                >
                  Delete
                </button>
                <button
                  className="btn btn-primary"
                  onClick={() => handleEditProduct(_id)}
                >
                  Edit
                </button>
              </>
            ) : null}
            <button
              className="btn btn-primary"
              onClick={() => handleAddToCart(_id)}
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    );
  });

  return (
    <>
      <h3 className="text-center my-4">All products are here...{count}</h3>
      <div className="container">
        {products.length > 0 ? (
          <div className="row">{renderList}</div>
        ) : (
          <div className="d-flex justify-content-center my-4">
            <div className="spinner-border" role="status">
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default ProductsDashboard;
