import React from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";

const CartComponent = ({ user }) => {
  const cart = user.cart;

  const handleRemoveFromCart = (id) => {
    console.log(id);
  };

  const cartArray = Object.values(cart);

  const renderList = cartArray.map((product) => {
    if (!product || typeof product !== "object") {
      return null;
    }
    const { id, title, image, price, category } = product;
    return (
      <div className="col-md-4 mb-4 px-4" key={id}>
        <Link to={`/cart/${id}`} className="text-decoration-none">
          <div className="ui link cards">
            <div className="card">
              <div className="image">
                <img src={image} alt={title} />
              </div>
              <div className="content">
                <div className="header mx-3">{title}</div>
                <div className="meta price mx-3">$ {price}</div>
                <div className="meta mx-3">{category}</div>
              </div>
            </div>
          </div>
        </Link>
        <div className="d-flex justify-content-between m-3">
          <button className="btn btn-primary">Buy</button>
          <button
            className="btn btn-primary"
            onClick={handleRemoveFromCart(id)}
          >
            Remove
          </button>
        </div>
      </div>
    );
  });
  return (
    <>
      <h3 className="text-center my-4">All Cart products are here...</h3>
      <div className=" container">
        <div className="row">{renderList}</div>
      </div>
    </>
  );
};

export default CartComponent;
