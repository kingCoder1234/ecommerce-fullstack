import React, { useEffect, useState } from "react";
import axios from "axios";
import { Route, Routes } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import UsersDashboard from "./UsersDashboard";
import UserDetails from "./UserDetails";
import Userprofile from "./Userprofile";
import { setUsers } from "../../redux/actions/usersActions";

const withWrapper = (WrappedComponent) => {
  return ({ Loggedinuser, ...props }) => {
    const dispatch = useDispatch();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const users = useSelector((state) => state.allUsers.users);

    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await axios.get("http://localhost:5000/api/users");
          dispatch(setUsers(response.data));
          setLoading(false);
        } catch (error) {
          setError(error.message);
          setLoading(false);
        }
      };

      fetchData();
    }, [dispatch]);

    if (loading) {
      return (
        <div className="d-flex justify-content-center my-4">
          <div className="spinner-border" role="status">
            <span className="sr-only">Loading...</span>
          </div>
        </div>
      );
    }

    if (error) {
      return <div>Error: {error}</div>;
    }

    return <WrappedComponent {...props} users={users} Loggedinuser={Loggedinuser} />;
  };
};

const WrappedUsersDashboard = withWrapper(UsersDashboard);
const WrappedUserDetails = withWrapper(UserDetails);
const WrappedUserProfile = withWrapper(Userprofile);

const UsersHigherOrderComponent = ({ Loggedinuser }) => (
  <Routes>
    <Route
      path="/"
      element={<WrappedUsersDashboard Loggedinuser={Loggedinuser} />}
    />
    <Route
      path="/profile"
      element={<WrappedUserProfile Loggedinuser={Loggedinuser} />}
    />
    <Route
      path="/:userId"
      element={<WrappedUserDetails Loggedinuser={Loggedinuser} />}
    />{" "}
  </Routes>
);

export default UsersHigherOrderComponent;
