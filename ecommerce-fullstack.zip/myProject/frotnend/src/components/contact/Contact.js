import React from 'react'

const Contact = () => {
  return (
    <div style={{height:"550px"}}>
      <h3 className='text-center'>This is Contact us page</h3>
    </div>
  )
}

export default Contact
