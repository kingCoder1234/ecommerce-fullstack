import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/home/Home";
import "./App.css";
import Header from "./components/header/Header";
import Signup from "./components/signin_signup/Signup";
import Signin from "./components/signin_signup/Signin";
import { useDispatch, useSelector } from "react-redux";
import { getUserInfo } from "./redux/actions/authActions";
import Contact from "./components/contact/Contact";
import About from "./components/about/About";
import Footer from "./components/footer/Footer";
import ProductsHigherOrderComponent from "./components/products/ProductsHigherOrderComponent";
import UsersHigherOrderComponent from "./components/user/UsersHigherOrderComponent";
import CartHigherOrderComponent from "./components/cart/CartHigherOrderComponent";

function App() {
  const [userInfo, setUserInfo] = useState(null);

  let auth = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    if (auth.token) {
      dispatch(getUserInfo())
        .then((userInfo) => {
          setUserInfo(userInfo);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  }, [auth.token, dispatch]);

  return (
    <div className="App">
      <BrowserRouter>
        <Header Loggedinuser={userInfo} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Signin />} />
          <Route path="/contact_us" element={<Contact />} />
          <Route path="/about" element={<About />} />


          <Route
            path="/products/*"
            element={<ProductsHigherOrderComponent Loggedinuser={userInfo} />}
          />
          <Route
            path="/users/*"
            element={<UsersHigherOrderComponent Loggedinuser={userInfo} />}
          />

          <Route
            path="/user/:userId/cart/*"
            element={
              userInfo ? (
                <CartHigherOrderComponent Loggedinuser={userInfo} />
              ) : null
            }
          />

          <Route path="*" element={<NotFound />} />
        </Routes>
        <Footer />
      </BrowserRouter>
    </div>
  );
}
const NotFound = () => {
  return <h1 className="text-center">Ooops! Page not found</h1>;
};
export default App;
