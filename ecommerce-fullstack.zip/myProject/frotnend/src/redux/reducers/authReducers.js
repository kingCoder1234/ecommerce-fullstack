import { ActionTypes } from "../constants/action-types";

const MY_ECOMMERCE_TOKEN = "My_ecommerce_token";

const initialState = {
  token: localStorage.getItem(MY_ECOMMERCE_TOKEN),
  user: null,
  loading: true,
  isAuthenticated: false,
  error: null,
};

const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case ActionTypes.LOGIN_SUCCESS:
      return {
        ...state,
        loading: false,
        token: action.payload,
        isAuthenticated: true,
        error: null,
      };
    case ActionTypes.LOGIN_FAILURE:
      return {
        ...state,
        token: null,
        loading: false,
        isAuthenticated: false,
        error: action.payload,
      };
    case ActionTypes.GET_USER_SUCCESS:
      return {
        ...state,
        loading: false,
        user: action.payload,
        error: null,
      };
    case ActionTypes.GET_USER_FAIL:
      return {
        ...state,
        loading: false,
        user: null,
        error: action.payload,
      };
    default:
      return state;
  }
};

export default authReducer;
