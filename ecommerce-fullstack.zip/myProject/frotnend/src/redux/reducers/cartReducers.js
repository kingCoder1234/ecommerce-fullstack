// cartReducer.js
import { ActionTypes } from "../constants/action-types";

const initialState = {
  cartItems: [],
  loading: false,
  error: null,
};

const cartReducer = (state = initialState, action) => {
  switch (action.type) {
    case ActionTypes.SET_CART:
      return {
        ...state,
        cartItems: action.payload,
        loading: false,
        error: null,
      };
    case ActionTypes.SET_CART_LOADING:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case ActionTypes.SET_CART_ERROR:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case ActionTypes.ADD_TO_CART_SUCCESS:
      return {
        ...state,
        cartItems: [...state.cartItems, action.payload],
        error: null,
      };
    case ActionTypes.ADD_TO_CART_FAIL:
      return {
        ...state,
        error: action.payload,
      };
    case ActionTypes.UPDATE_ITEM_QUANTITY_SUCCESS:
      const updatedItems = state.cartItems.map((item) => {
        if (item.id === action.payload.id) {
          return {
            ...item,
            quantity: action.payload.quantity,
          };
        }
        return item;
      });
      return {
        ...state,
        cartItems: updatedItems,
        error: null,
      };
    case ActionTypes.UPDATE_ITEM_QUANTITY_FAILURE:
      return {
        ...state,
        error: action.payload,
      };
    default:
      return state;
  }
};

export default cartReducer;
