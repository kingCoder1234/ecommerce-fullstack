import React from "react";
import { Link } from "react-router-dom";
import img from "./profilepic.jpg"
const UsersDashboard = ({ users, Loggedinuser }) => {
  const allUsers = users.map((person) => {
    const { _id, name, email, age } = person;
    return (
      <div className="col-lg-4 col-md-4 col-sm-6 mb-4 py-4 px-4" key={_id}>
        <Link to={`/users/${_id}`} className="text-decoration-none">
          <div className="card h-100">
            <img src={img} className="card-img-top py-3 px-3" alt="loading..." />
            <div className="card-body">
              <h5 className="card-title">{name}</h5>
              <p className="card-text">{email}</p>
              <p className="card-text">{age}</p>
            </div>
          </div>
        </Link>
        <div
          className="d-flex justify-content-between"
          style={{ fontSize: "25px" }}
        >
          <i className="fa fa-trash btn btn-primary"></i>
          <i className="fa fa-edit btn btn-primary"></i>
        </div>
      </div>
    );
  });
  return (
    <>
      <h3 className="text-center my-4">All Users are here...</h3>
      <div className="container">
        {users.length > 0 ? (
          <div className="row">{allUsers}</div>
        ) : (
          <div className="d-flex justify-content-center my-4">
            <div className="spinner-border" role="status">
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default UsersDashboard;
