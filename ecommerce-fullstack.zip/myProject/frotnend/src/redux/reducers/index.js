import { combineReducers } from "redux";
import { productsReducer, selectedProductsReducer } from "./productsReducer";
import authReducer from "./authReducers";
import { usersReducer, selectedUserReducer } from "./userReducers";
import cartReducer from "./cartReducers";
const reducers = combineReducers({
  allProducts: productsReducer,              //for all products
  product: selectedProductsReducer,          //for one selected product
  cart: cartReducer,                         //To Add product to cart
  auth: authReducer,                         //for signup/signin
  allUsers: usersReducer,                    //for all users
  user: selectedUserReducer,                 //for one selected user
});
export default reducers;
