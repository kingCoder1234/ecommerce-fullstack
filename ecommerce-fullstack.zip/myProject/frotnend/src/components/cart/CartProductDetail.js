import React from "react";
import { useParams, Link } from "react-router-dom";

const CartProductDetail = ({ Loggedinuser, cartData, handleItemQuantity }) => {
  const { productId } = useParams();

  const cartItem = cartData.find((item) => item.productId === productId);
  const product = cartItem
    ? {
        _id: cartItem.productId,
        title: cartItem.product.title,
        price: cartItem.product.price,
        description: cartItem.product.description,
        category: cartItem.product.category,
        image: cartItem.product.image,
        quantity: cartItem.quantity,
      }
    : null;

  const handlebuy = (price) => {
    alert(price);
  };

  return (
    <div>
      <h3>This is individual cart product</h3>
      <div className="ui grid container">
        {Loggedinuser && Loggedinuser.isAdmin ? (
          <Link to={"/products"} className="btn btn-primary">
            <i className="fa fa-arrow-circle-left"></i> back
          </Link>
        ) : null}
        {product ? (
          <div className="ui placeholder segment">
            <div className="ui two column stackable center aligned grid">
              <div className="middle aligned row">
                <div className="column lp">
                  <img
                    className="product-img rounded float-left"
                    src={product.image}
                    alt={product.title}
                  />
                </div>
                <div className="column rp">
                  <h3>{product.title}</h3>
                  <h3>
                    <a className="ui teal tag label">${product.price}</a>
                  </h3>
                  <h4 className="ui brown block header">{product.category}</h4>
                  <p>{product.description}</p>
                  <div className="ui vertical animated" tabIndex="0">
                    <div className="d-flex justify-content-between">
                      <div>
                        <button
                          className="btn btn-primary"
                          onClick={() => {
                            handleItemQuantity(product._id, -1); // Corrected to pass product._id as productId
                          }}
                        >
                          -
                        </button>
                      </div>
                      <div>
                        <input
                          type="text"
                          value={cartItem.quantity}
                          readOnly
                          className="text-center inputQuantity"
                        />
                      </div>
                      <div>
                        <button
                          className="btn btn-primary"
                          onClick={() => {
                            handleItemQuantity(product._id, 1); // Corrected to pass product._id as productId
                          }}
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <div className="d-flex justify-content-between">
                      {Loggedinuser && Loggedinuser.isAdmin ? (
                        <>
                          <i
                            className="fa fa-trash btn btn-primary"
                            style={{ fontSize: "25px" }}
                            onClick={() => handleDeleteProduct(product._id)}
                          ></i>
                          <button
                            className="btn btn-primary"
                            onClick={() => editProduct(product._id)}
                          >
                            Edit
                          </button>
                        </>
                      ) : null}
                      <button
                        className="btn btn-primary"
                        onClick={() => handlebuy(product.price)}
                      >
                        Buy
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="d-flex justify-content-center my-4">
            <div className="spinner-border" role="status">
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartProductDetail;
