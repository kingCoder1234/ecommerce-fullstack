import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { signupUser } from "../../redux/actions/authActions";

const Signup = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    age: "",
    password: "",
    isAdmin: "false",
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.name ||
      !formData.email ||
      !formData.password ||
      !formData.age
    ) {
      toast.error("Fill all details");
      return;
    }

    try {
      const data = await dispatch(signupUser(formData));
      // console.log("data ", data.status);
      if (data.message === "Signup  Successfully!") {
        toast.success(data.message);
        navigate("/login");
      }
    } catch (error) {
      toast.error(error);
    }
  };

  return (
    <div className="container px-5 py-5">
      <h3 className="text-center">Signup here </h3>
      <form className="px-5 py-5" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="exampleInputName">Your Name </label>
          <input
            type="text"
            name="name"
            value={formData.name}
            className="form-control"
            id="exampleInputName"
            aria-describedby="NameHelp"
            placeholder="Enter Name"
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">Email address</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            placeholder="Enter email"
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputAge">Your Age </label>
          <input
            type="number"
            name="age"
            value={formData.age}
            className="form-control"
            id="exampleInputAge"
            aria-describedby="AgeHelp"
            placeholder="Enter Age"
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            className="form-control"
            id="exampleInputPassword1"
            placeholder="Password"
            onChange={handleChange}
          />
        </div>
        <div className="text-center py-3">
          <button type="submit" className="btn btn-primary">
            Sign Up
          </button>
          <div>
            <Link to="/login">Already have an account? </Link>
          </div>
        </div>
      </form>
      <ToastContainer position="top-center" autoClose={2500} />
    </div>
  );
};

export default Signup;
