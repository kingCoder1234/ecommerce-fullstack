import React, { useEffect, useState } from "react";
import axios from "axios";
import { Route, Routes } from "react-router-dom";
import CartDashboard from "./CartDashboard";
import CartProductDetail from "./CartProductDetail";
import { useDispatch, useSelector } from "react-redux";
import { setcart, updateItemQuantity } from "../../redux/actions/cartActions";
import { toast } from "react-toastify";

const withWrapper = (WrappedComponent) => {
  return ({ Loggedinuser, ...props }) => {
    const dispatch = useDispatch();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const cartData = useSelector((state) => state.cart.cartItems);

    useEffect(() => {
      const fetchCartData = async () => {
        try {
          if (!Loggedinuser || !Loggedinuser.cart) {
            throw new Error("User cart data not available");
          }
          const productIds = Loggedinuser.cart.map((item) => item.productId);
          const response = await axios.get(
            `http://localhost:5000/api/products`,
            {
              params: {
                ids: productIds.join(","),
              },
            }
          );
          const productsData = response.data;

          const mergedCartData = Loggedinuser.cart.map((item) => {
            const product = productsData.find(
              (it) => it._id === item.productId
            );
            return {
              ...item,
              product,
            };
          });
          dispatch(setcart(mergedCartData));
        } catch (error) {
          setError(error.message);
          toast.error("Failed to fetch cart data");
        } finally {
          setLoading(false);
        }
      };

      fetchCartData();
    }, [dispatch, Loggedinuser]);

    const handleItemQuantity = async (itemId, change) => {
      try {
        await dispatch(updateItemQuantity(itemId, change));
        toast.success("Quantity updated successfully");
      } catch (error) {
        toast.error("Error updating quantity: " + error.message);
      }
    };

    if (loading) {
      return (
        <div className="d-flex justify-content-center my-4">
          <div className="spinner-border" role="status">
            <span className="sr-only">Loading...</span>
          </div>
        </div>
      );
    }

    if (error) {
      return <div>Error: {error}</div>;
    }

    return (
      <WrappedComponent
        {...props}
        Loggedinuser={Loggedinuser}
        cartData={cartData}
        handleItemQuantity={handleItemQuantity}
      />
    );
  };
};

const WrappedCartDashboard = withWrapper(CartDashboard);
const WrappedCartProductDetails = withWrapper(CartProductDetail);

const CartHigherOrderComponent = ({ Loggedinuser }) => (
  <Routes>
    <Route
      path="/"
      element={<WrappedCartDashboard Loggedinuser={Loggedinuser} />}
    />
    <Route
      path="/:productId"
      element={<WrappedCartProductDetails Loggedinuser={Loggedinuser} />}
    />
  </Routes>
);

export default CartHigherOrderComponent;
