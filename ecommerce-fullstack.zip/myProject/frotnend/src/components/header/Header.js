import React, { useState } from "react";
const MY_ECOMMERCE_TOKEN = "My_ecommerce_token";
import { toast, ToastContainer } from "react-toastify";

const Header = ({ Loggedinuser }) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };
  const handleLogout = () => {
    localStorage.removeItem(MY_ECOMMERCE_TOKEN);
    toast.success("Logout Successfully!");
    window.location.href = "/login";
  };

  return (
    <div>
      <nav className="myNav navbar navbar-expand-lg navbar-light bg-light">
        <a className="navbar-brand" href="/">
          ShopHere
        </a>
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item active">
              <a className="nav-link" href="/">
                Home
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="/products">
                Shopping
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="/signup">
                Signup
              </a>
            </li>
            {Loggedinuser && Loggedinuser.isAdmin ? (
              <li className="nav-item">
                <a className="nav-link" href="/users">
                  Users
                </a>
              </li>
            ) : null}
            <li className="nav-item">
              <a className="nav-link" href="/contact_us">
                Contact Us
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="/about">
                About
              </a>
            </li>
          </ul>
          <div className="form-inline my-lg-0">
            {Loggedinuser ? (
              <div
                className="dropdown mx-3"
                onMouseEnter={toggleDropdown}
                onMouseLeave={toggleDropdown}
              >
                <button
                  style={{ backgroundColor: "transparent", border: "0px" }}
                  className="dropdown-toggle"
                  type="button"
                  id="userDropdown"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded={isDropdownOpen ? "true" : "false"}
                >
                  <div className="d-flex flex-column">
                    <i className="fa fa-user" style={{ fontSize: "20px" }}></i>
                    <div>{Loggedinuser.name}</div>
                  </div>
                </button>
                <div
                  className={`dropdown-menu${isDropdownOpen ? " show" : ""}`}
                  aria-labelledby="userDropdown"
                >
                  <a className="dropdown-item" href="/users/profile">
                    Profile
                  </a>
                  <a className="dropdown-item" onClick={handleLogout}>
                    Logout
                  </a>
                </div>
              </div>
            ) : (
              <a className="btn my-2 my-sm-0" href="/login">
                Login
              </a>
            )}
            {Loggedinuser ? (
              <a className="btn my-2 my-sm-0" href={`/user/${Loggedinuser._id}/cart`}>
                <i
                  className="fa fa-shopping-cart"
                  style={{ fontSize: "25px" }}
                ></i>{" "}
                {Loggedinuser.cart.length}
              </a>
            ) : (
              <a className="btn my-2 my-sm-0" href="/login">
                <i
                  className="fa fa-shopping-cart"
                  style={{ fontSize: "25px" }}
                ></i>{" "}
              </a>
            )}
          </div>
        </div>
      </nav>
      <ToastContainer position="top-center" autoClose={1500} />
    </div>
  );
};

export default Header;
