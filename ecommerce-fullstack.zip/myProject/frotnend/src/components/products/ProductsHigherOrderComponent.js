import React, { useEffect, useState } from "react";
import axios from "axios";
import { Route, Routes } from "react-router-dom";
import ProductsDashboard from "./ProductsDashboard";
import ProductDetails from "./ProductDetails";
import { useDispatch, useSelector } from "react-redux";
import { removeSelectedProduct, setProducts } from "../../redux/actions/productsActions";
import { toast } from "react-toastify";
import { addToCart } from "../../redux/actions/cartActions";

const handleAddToCart = async (dispatch, productId, user) => {
  try {
    await dispatch(addToCart(productId, user._id));
    toast.success("Product added to cart successfully!");
  } catch (error) {
    toast.error("Error adding product to cart");
  }
};
const handleRemoveProduct = async (dispatch, productId) => {
  try {
    await dispatch(removeSelectedProduct(productId));
    toast.success("Product removed successfully!");
  } catch (error) {
    toast.error("Error removing product");
  }
};

const withWrapper = (WrappedComponent) => {
  return ({ Loggedinuser, ...props }) => {
    const dispatch = useDispatch();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const products = useSelector((state) => state.allProducts.products);

    useEffect(() => {
      const fetchData = async () => {
        try {
          const response = await axios.get(
            "http://localhost:5000/api/products"
          );
          dispatch(setProducts(response.data));
          setLoading(false);
        } catch (error) {
          setError(error.message);
          setLoading(false);
        }
      };
      fetchData();
    }, [dispatch]);

    if (loading) {
      return (
        <div className="d-flex justify-content-center my-4">
          <div className="spinner-border" role="status">
            <span className="sr-only">Loading...</span>
          </div>
        </div>
      );
    }

    if (error) {
      return <div>Error: {error}</div>;
    }

    return (
      <WrappedComponent
        {...props}
        products={products}
        Loggedinuser={Loggedinuser}
        handleAddToCart={(productId) =>
          handleAddToCart(dispatch, productId, Loggedinuser)
        }
        handleRemoveProduct={(productId) =>
          handleRemoveProduct(dispatch, productId)
        }
      />
    );
  };
};

const WrappedProductsDashboard = withWrapper(ProductsDashboard);
const WrappedProductDetails = withWrapper(ProductDetails);

const ProductsHigherOrderComponent = ({ Loggedinuser }) => (
  <Routes>
    <Route
      path="/"
      element={<WrappedProductsDashboard Loggedinuser={Loggedinuser} />}
    />
    <Route
      path="/:productId"
      element={<WrappedProductDetails Loggedinuser={Loggedinuser} />}
    />
  </Routes>
);

export default ProductsHigherOrderComponent;
