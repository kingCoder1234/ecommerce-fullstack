import React from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";

const CartDashboard = ({ cartData, Loggedinuser, handleItemQuantity }) => {
  const cart = useSelector((state)=>state.cart.cartItems)

  const handlebuy = (price) => {
    alert(price);
  };
  return (
    <div>
      <h2 className="text-center">Cart Products </h2>
      <h4 className="text-center">
        $100{" "}
        <button
          className="btn btn-primary"
          onClick={() => handlebuy(totalPrice.toFixed(2))}
        >
          Buy
        </button>
      </h4>
      {cartData.length === 0 ? (
        <div className="d-flex justify-content-center">
          <h3>No products are added yet</h3>
          <Link to={"/products"} style={{ fontSize: "25px" }}>
            <i className="fa fa-arrow-circle-left"></i>continue to shopping
          </Link>
        </div>
      ) : (
        <div className="container">
          <div className="row">
            {cartData.map((product) => {
              if (!product || typeof product !== "object") {
                return null;
              }
              const {
                quantity,
                product: { _id, title, image, price, category },
              } = product;
              return (
                <div className="col-md-4 mb-4 px-4" key={_id}>
                  <Link
                    to={`/user/${Loggedinuser._id}/cart/${_id}`}
                    className="text-decoration-none"
                  >
                    <div className="ui link cards">
                      <div className="card">
                        <div className="image">
                          <img src={image} alt={title} />
                        </div>
                        <div className="content">
                          <div className="header mx-3">{title}</div>
                          <div className="meta price mx-3">$ {price}</div>
                          <div className="meta mx-3">{category}</div>
                        </div>
                      </div>
                    </div>
                  </Link>
                  <div className="d-flex justify-content-between m-3">
                    <button
                      className="btn btn-primary"
                      onClick={() => handlebuy(price)}
                    >
                      Buy
                    </button>
                    <div className="d-flex justify-content-center">
                      <button
                        className="btn btn-primary"
                        onClick={() => {
                          handleItemQuantity(_id, -1);
                        }}
                      >
                        -
                      </button>
                      <input
                        type="text"
                        value={quantity || ""}
                        readOnly
                        className="text-center inputQuantity"
                        style={{
                          width: "20%",
                          margin: "auto",
                        }}
                      />
                      <button
                        className="btn btn-primary"
                        onClick={() => {
                          handleItemQuantity(_id, 1);
                        }}
                      >
                        +
                      </button>
                    </div>
                    <button className="btn btn-primary">Remove</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default CartDashboard;
