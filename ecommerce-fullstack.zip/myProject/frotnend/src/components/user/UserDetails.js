import React from "react";
import { Link, useParams } from "react-router-dom";
import img from "../user/profilepic.jpg";
const UserDetails = ({ users, Loggedinuser }) => {
  const { userId } = useParams();
  const selectedUser = users.find((itm) => itm._id === userId);

  return (
    <div className="container">
      <div className="card mb-3">
        <div>
          <Link to={"/users"} className="btn btn-primary">
            <i className="fa fa-arrow-circle-left"></i> back to All Users
          </Link>
        </div>
        <div className="img-container d-flex justify-content-center py-4">
          <img src={img} className="card-img-top profile-pic" alt="..." />
        </div>
        <div className="card-body text-center">
          <div>
            <h5 className="card-title">{selectedUser.name}</h5>
          </div>
          <h5 className="card-title">{selectedUser.email}</h5>
          <h5 className="card-title">Your Mobile Number</h5>
          <h5 className="card-title">Your address</h5>
        </div>
        <div
          className="d-flex justify-content-between"
          style={{ width: "50%", margin: "auto", fontSize: "25px" }}
        >
          <i className="fa fa-trash btn btn-primary"></i>
          <i className="fa fa-edit btn btn-primary"></i>
        </div>
      </div>
    </div>
  );
};

export default UserDetails;

{
  /* <div> */
}
//   <h2 className="text-center">User Details</h2>
//   <div className="ui grid container">
//     {selectedUser && Object.keys(selectedUser).length !== 0 ? (
//       <div className="ui placeholder segment">
//         <div className="ui two column stackable center aligned grid">
//           <div className="middle aligned row">
//             <div className="column lp">
//               <img
//                 className="product-img rounded float-left"
//                 src=""
//                 alt="loading..."
//               />
//             </div>
//             <div className="column rp">
//               <h3>{selectedUser.name}</h3>
//               <h3>
//                 <a className="ui teal tag label">{selectedUser.email}</a>
//               </h3>
//               <h4 className="ui brown block header">{selectedUser.age}</h4>
//               <div className="ui vertical animated button" tabIndex="0">
//                 <div className="hidden content">
//                   <i className="shop icon"></i>
//                 </div>
//                 <div
//                   className="d-flex justify-content-between"
//                 >
//                   <i className="fa fa-trash"></i>
//                   <i className="fa fa-edit"></i>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     ) : (
//       <div className="d-flex justify-content-center my-4">
//         <div className="spinner-border" role="status">
//           <span className="sr-only">Loading...</span>
//         </div>
//       </div>
//     )}
//   </div>
// </div>
