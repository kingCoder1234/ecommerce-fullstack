import { ActionTypes } from "../constants/action-types";
import axios from 'axios';

export const setProducts = (products) => {
  return {
    type: ActionTypes.SET_PRODUCTS,
    payload: products,
  };
};

export const selectedProduct = (product) => {
  return {
    type: ActionTypes.SELECTED_PRODUCT,
    payload: product,
  };
};


export const removeSelectedProduct = (productId) => {
  return async (dispatch) => {
    try {
      const response = await axios.delete(`http://localhost:5000/api/product/${productId}`);
      dispatch({
        type: ActionTypes.REMOVE_SELECTED_PRODUCT,
        payload: productId
      });
      console.log("Product removed successfully:", response.data);
    } catch (error) {
      console.error("Error removing product:", error.message);
    }
  };
};
