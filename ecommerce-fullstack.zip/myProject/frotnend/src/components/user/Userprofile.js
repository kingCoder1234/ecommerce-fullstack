import React, { useState } from "react";
import img from "./profilepic.jpg";
import "./style.css";
import { Link } from "react-router-dom";
import { ToastContainer } from "react-toastify";

const Userprofile = ({ Loggedinuser }) => {
  const [settingDisplay, setSettingDisplay] = useState(false);
  const [settingDisplayuser, setSettingDisplayuser] = useState(false);

  const toggleSettingDisplay = () => {
    setSettingDisplay(!settingDisplay);
  };
  const toggleSettingDisplayEditUser = () => {
    setSettingDisplayuser(!settingDisplayuser);
  };
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    address:""
  });
  const handleChange = (e) => {};
  const handleSubmit = async (e) => {};
  const formEdit = () => {
    return (
      <div className="container px-5 py-5">
        <i className="fa fa-close float-right" style={{fontSize:"25px"}} onClick={toggleSettingDisplayEditUser}></i>
        <h3 className="text-center">Signup here </h3>
        <form className="px-5 py-5" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="exampleInputName">Your Name </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              className="form-control"
              id="exampleInputName"
              aria-describedby="NameHelp"
              placeholder="Enter Name"
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputAge">Your Age </label>
            <input
              type="number"
              name="age"
              value={formData.age}
              className="form-control"
              id="exampleInputAge"
              aria-describedby="AgeHelp"
              placeholder="Enter Age"
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="exampleInputPassword1">Address</label>
            <input
              type="text"
              name="Address"
              value={formData.address}
              className="form-control"
              id="exampleInputAddress"
              placeholder="Address"
              onChange={handleChange}
            />
          </div>
          <div className="text-center py-3">
            <button type="submit" className="btn btn-primary">
              Update Profile 
            </button>
          </div>
        </form>
      </div>
    );
  };
  const userSetting = (Loggedinuser) => {
    return (
      <div className="container">
        {Loggedinuser ? <h3>{Loggedinuser.name}</h3> : <h3>Loading...</h3>}
        <h5>
          <i className="fa fa-key"></i>Account{" "}
        </h5>
        <h5>
          <i className="fa fa-bell"></i>Notifications{" "}
        </h5>
        <h5>
          <i className="fa fa-edit"></i>Personalization{" "}
        </h5>
        <h5>
          <i className="fa fa-support"></i>Help{" "}
        </h5>
      </div>
    );
  };

  return (
    <div className="container">
      {Loggedinuser ? (
        <div className="card mb-3">
          <div onClick={toggleSettingDisplay}>
            {settingDisplay ? (
              <i className="fa fa-close" style={{ fontSize: "30px" }}></i>
            ) : (
              <i className="fa fa-gear" style={{ fontSize: "30px" }}></i>
            )}
          </div>
          <div className="img-container d-flex justify-content-center py-4">
            <img src={img} className="card-img-top profile-pic" alt="..." />
          </div>
          <div className="card-body text-center">
            <div>
              <h5 className="card-title">{Loggedinuser.name}</h5>
            </div>
            <h5 className="card-title">{Loggedinuser.email}</h5>
            <h5 className="card-title">Your Mobile Number</h5>
            <h5 className="card-title">Your address</h5>
            <div className="d-flex justify-content-center">
              <i
                className="fa fa-edit btn btn-primary"
                style={{ fontSize: "25px" }}
                onClick={toggleSettingDisplayEditUser}
              ></i>
            </div>
          </div>
          <div>
            {settingDisplayuser && (
              <div
                style={{
                  position: "absolute",
                  top: "0",
                  left: "50%",
                  transform: "translateX(-50%)",
                  width: "70%",
                  height: "auto",
                  backgroundColor: "#f0f0f0",
                  border: "1px solid #ccc",
                  padding: "20px",
                  zIndex: 999,
                  transition: "transform 0.3s ease-in-out",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                {formEdit()}
              </div>
            )}
            {settingDisplay && (
              <div
                style={{
                  position: "absolute",
                  top: "8%",
                  left: 0,
                  width: "30%",
                  height: "auto",
                  backgroundColor: "#f0f0f0",
                  border: "1px solid #ccc",
                  padding: "20px",
                  zIndex: 999,
                  transition: "transform 0.3s ease-in-out",
                }}
              >
                {userSetting(Loggedinuser)}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="d-flex justify-content-center my-4">
          <div className="spinner-border" role="status">
            <span className="sr-only">Loading...</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default Userprofile;
