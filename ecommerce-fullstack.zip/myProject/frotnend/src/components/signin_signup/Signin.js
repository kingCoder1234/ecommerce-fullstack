import React, { useState } from "react";
import { Link } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { signinUser } from "../../redux/actions/authActions";
import { useDispatch, useSelector } from "react-redux";
const MY_ECOMMERCE_TOKEN = "My_ecommerce_token";

const Signin = () => {
  const dispatch = useDispatch();

  const [loginData, setloginData] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setloginData({
      ...loginData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!loginData.email || !loginData.password) {
      toast.error("Email and password are required");
      return;
    }
    try {
      const response = await dispatch(signinUser(loginData));
      if (response.status) {
        const token = response.data.token;
        localStorage.setItem(MY_ECOMMERCE_TOKEN, token);
        toast.success(response.data.message);
        setTimeout(async () => {
          window.location.href = "/products";
        }, 2000);
      }
    } catch (error) {
      toast.error(error);
    }
  };
  
  return (
    <div className="container px-5 py-5">
      <h3 className="text-center">Signin here</h3>
      <form className="px-5 py-5" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">Email address</label>
          <input
            type="email"
            name="email"
            value={loginData.email}
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            placeholder="Enter email"
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input
            type="password"
            name="password"
            value={loginData.password}
            className="form-control"
            id="exampleInputPassword1"
            placeholder="Password"
            onChange={handleChange}
          />
        </div>
        <div className="text-center py-3">
          <button type="submit" className="btn btn-primary">
            Login
          </button>
          <div>
            <Link to="/signup">Create Account </Link>
          </div>
        </div>
      </form>
      <ToastContainer position="top-center" autoClose={1500} />
    </div>
  );
};

export default Signin;
