import React from "react";

const Footer = () => {
  return (
    <div style={{ width: "100%", height: "auto", backgroundColor: "black" }}>
      <h3 className="text-center text-light">This is Footer</h3>
      <ul className="text-center text-light w-50 m-auto list-unstyled">
        <li>
          <a
            className="text-light"
            href="https://www.facebook.com"
            target="_blank"
          >
            <i className="fa fa-facebook"></i> facebook
          </a>
        </li>
        <li>
          <a
            className="text-light"
            href="https://www.instagram.com"
            target="_blank"
          >
            <i className="fa fa-instagram"></i> instagram
          </a>
        </li>
        <li>
          <a
            className="text-light"
            href="https://www.youtube.com"
            target="_blank"
          >
            <i className="fa fa-youtube"></i> youtube
          </a>
        </li>
        <li>
          <a
            className="text-light"
            href="https://www.twitter.com"
            target="_blank"
          >
            <i className="fa fa-twitter"></i> twitter
          </a>
        </li>
        <li>
          <a
            className="text-light"
            href="https://www.gmail.com"
            target="_blank"
          >
            <i className="fa fa-envelope"></i> gmail
          </a>
        </li>
      </ul>
    </div>
  );
};

export default Footer;
