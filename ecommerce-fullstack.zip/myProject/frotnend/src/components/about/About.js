import axios from "axios";
import React, { useEffect } from "react";

const About = () => {
  const itemId = 10;
  const change = 1;
  const fetchData = async () => {
    console.log("Hello___")
    try {
      const response = await axios.put(
        `http://localhost:5000/api/cartist`
      );
      console.log(response.data);
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <div>
      <h3 className="text-center">This is About page </h3>
      <button onClick={fetchData}>Hello___</button>
    </div>
  );
};

export default About;
