import axios from "axios";
import { ActionTypes } from "../constants/action-types";
const MY_ECOMMERCE_TOKEN = "My_ecommerce_token";

export const signupUser = (formData) => async (dispatch) => {
  try {
    const res = await axios.post("http://localhost:5000/api/signup", formData);
    dispatch({
      type: ActionTypes.SIGNUP_SUCCESS,
      payload: res.data,
    });
    return res.data;
  } catch (error) {
    dispatch({
      type: ActionTypes.SIGNUP_FAILURE,
      payload: {
        error: error.response.data.error,
      },
    });
    throw error.response.data.error;
  }
};
export const signinUser = (loginData) => async (dispatch) => {
  try {
    const res = await axios.post("http://localhost:5000/api/login", loginData);
    dispatch({
      type: ActionTypes.LOGIN_SUCCESS,
      payload: res,
    });
    return res;
  } catch (error) {
    dispatch({
      type: ActionTypes.LOGIN_FAILURE,
      payload: {
        error: error.response.data.error,
      },
    });
    throw error.response.data.error;
  }
};
export const getUserInfo = () => async (dispatch) => {
  try {
    const token = localStorage.getItem(MY_ECOMMERCE_TOKEN);
    const config = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };
    const res = await axios.get("http://localhost:5000/api/profile", config);
    dispatch({ type: ActionTypes.GET_USER_SUCCESS, payload: res.data });
    return res.data;
  } catch (error) {
    dispatch({
      type: ActionTypes.GET_USER_FAIL,
      payload: error.response.data.message,
    });
    throw error.response.data.message;
  }
};
