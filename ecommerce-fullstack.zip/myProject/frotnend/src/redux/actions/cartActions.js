import { ActionTypes } from "../constants/action-types";
import axios from "axios";
const MY_ECOMMERCE_TOKEN = "My_ecommerce_token";

export const addToCart = (itemId, userId) => async (dispatch) => {
  try {
    const token = localStorage.getItem("token");
    const response = await axios.post(
      `http://localhost:5000/api/${userId}/cart`,
      { itemId },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    dispatch({
      type: ActionTypes.ADD_TO_CART_SUCCESS,
      payload: response.data,
    });
    return response.data;
  } catch (error) {
    console.error("Error adding product to cart:", error);
    dispatch({
      type: ActionTypes.ADD_TO_CART_FAIL,
      payload: error.response || error.message,
    });
    throw error;
  }
};
export const setcart = (cartData) => {
  return {
    type: ActionTypes.SET_CART,
    payload: cartData,
  };
};
export const selectedcartProduct = (product) => {
  return {
    type: ActionTypes.SELECTED_CART_PRODUCT,
    payload: product,
  };
};
export const removeSelectedcartProduct = () => {
  return {
    type: ActionTypes.REMOVE_SELECTED_CART_PRODUCT,
  };
};
export const updateItemQuantity = (itemId, change) => {
  return async (dispatch) => {
    try {
      const token = localStorage.getItem(MY_ECOMMERCE_TOKEN);
      if (!token) {
        console.error("Token not found");
        throw new Error("Token not found");
      }

      const response = await axios.put(
        `http://localhost:5000/api/cart/${itemId}/${change}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        dispatch({
          type: ActionTypes.UPDATE_ITEM_QUANTITY_SUCCESS,
          payload: response.data.quantity,
        });
        console.log("Quantity updated successfully");
      }
    } catch (error) {
      dispatch({
        type: ActionTypes.UPDATE_ITEM_QUANTITY_FAILURE,
        payload: error.message,
      });
      console.error("Error updating quantity:", error);
    }
  };
};
